export class Recipe {
  title: string;
  ingredients: string;
  instructions: string;
  difficulty: number;
  time: number;
  _id: string;
}
